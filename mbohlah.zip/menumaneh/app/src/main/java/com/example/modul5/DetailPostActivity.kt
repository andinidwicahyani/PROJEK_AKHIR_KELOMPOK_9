package com.example.modul5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DetailPostActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_post)
    }
}