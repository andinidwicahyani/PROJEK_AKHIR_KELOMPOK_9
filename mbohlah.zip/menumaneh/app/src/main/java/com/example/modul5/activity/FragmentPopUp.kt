package com.example.modul5.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.updateLayoutParams
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.ViewModelProvider
import com.example.modul5.R
import com.example.modul5.UpdatePostActivity
import com.example.modul5.room.PostDatabase
import com.example.modul5.room.PostViewModel
import com.example.modul5.room.PostViewModelFactory
import com.google.android.material.button.MaterialButton
import android.util.Log
import android.os.Parcelable

class FragmentPopUp(private val postDatabase: PostDatabase) : DialogFragment() {
    private lateinit var appViewModel: PostViewModel

    override fun getTheme(): Int {
        return R.style.circular
    }

    override fun onStart() {
        super.onStart()
        requireDialog().window?.apply {
            setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        view?.updateLayoutParams<ViewGroup.MarginLayoutParams> {
            setMargins(16, 16, 16, 16)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.activity_fragment_pop_up, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val factory = PostViewModelFactory.getInstance(requireContext().applicationContext)
        appViewModel = ViewModelProvider(requireActivity(), factory)[PostViewModel::class.java]

        val btnUbah: MaterialButton = view.findViewById(R.id.btn_ubah)
        val btnHapus: MaterialButton = view.findViewById(R.id.btn_hapus)

        btnUbah.setOnClickListener {
            Log.d(TAG, "Ubah button clicked")
            val intent = Intent(requireContext(), UpdatePostActivity::class.java)
            intent.putExtra("postDatabase", postDatabase as Parcelable)
            startActivity(intent)
            dismiss()
        }

        btnHapus.setOnClickListener {
            Log.d(TAG, "Hapus button clicked")
            appViewModel.deletePost(postDatabase)
            dismiss()
        }
    }

    companion object {
        const val TAG = "FragmentPopUp"
    }
}