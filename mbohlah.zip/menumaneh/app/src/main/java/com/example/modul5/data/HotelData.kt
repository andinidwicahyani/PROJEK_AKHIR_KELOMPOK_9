package com.example.modul5.data

data class HotelData (
    val name: String,
    val description: String,
    val tempat: String,
    val image: Int

)