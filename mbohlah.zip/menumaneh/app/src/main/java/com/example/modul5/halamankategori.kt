package com.example.modul5

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.modul5.ActivityMakanan
import com.example.modul5.ActivityMinuman

class halamankategori : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_halamankategori)

        // Temukan tombol ImageButton dengan id btn_makanan
        val btnMakanan = findViewById<ImageButton>(R.id.btn_makanan)

        // Tambahkan OnClickListener untuk ImageButton
        btnMakanan.setOnClickListener {
            // Buat Intent untuk pindah ke ActivityMakanan
            val intent = Intent(
                this@halamankategori,
                ActivityMakanan::class.java
            )
            startActivity(intent)
        }

        // Temukan tombol ImageButton dengan id btn_minuman
        val btnMinuman = findViewById<ImageButton>(R.id.btn_minuman)

        // Tambahkan OnClickListener untuk ImageButton
        btnMinuman.setOnClickListener {
            // Buat Intent untuk pindah ke ActivityMinuman
            val intent = Intent(
                this@halamankategori,
                ActivityMinuman::class.java
            )
            startActivity(intent)
        }
    }
}
