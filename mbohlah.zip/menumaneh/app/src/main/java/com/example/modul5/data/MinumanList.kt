package com.example.modul5.data

import com.example.modul5.R


object MinumanList {

    val Data = arrayListOf(
        HotelData(
            "ES OYEN",
            "Soto (juga dikenal dengan beberapa nama lokal seperti, sroto, sauto, tauto, atau coto) adalah makanan khas Indonesia seperti sop yang terbuat dari kaldu daging dan sayuran. Daging yang paling sering digunakan adalah daging sapi dan daging ayam, tetapi ada pula yang menggunakan daging babi, daging kuda atau daging kambing",
            "Jawa Timur",
            R.drawable.oyen
        ),
        HotelData(
            "ES SELENDANG MAYANG",
            "Bakso sangat populer dan dapat ditemukan di seluruh Indonesia, dari gerobak pedagang kaki lima hingga restoran besar. Berbagai jenis bakso sekarang banyak ditawarkan dalam bentuk makanan beku yang dijual di pasar swalayan ataupun mal-mal. Irisan bakso dapat juga dijadikan pelengkap jenis makanan lain seperti mi goreng, nasi goreng, sop atau capca",
            "Malang",
            R.drawable.selendang
        ),
        HotelData(
            "ES GOBAK SODOR",
            "Gudeg sangat populer di Jawa, hidangan ini merupakan hidangan populer baik sebagai masakan rumahan maupun hidangan jalanan. Gudeg juga diproduksi secara industri sebagai makanan kaleng. Gudeg juga bisa ditemui di luar Indonesia, khususnya di negara tetangga seperti Malaysia dan Singapura",
            "Jogja",
            R.drawable.gobak
        ),
        HotelData(
            "ES DOGER",
            "Asal usul rendang ditelusuri berasal dari tanah Minangkabau, Sumatera Barat. Bagi masyarakat Minang, rendang sudah ada sejak dahulu dan telah menjadi masakan tradisi yang dihidangkan dalam berbagai acara adat dan hidangan keseharian",
            "Sumatera",
            R.drawable.doger
        ),
        HotelData(
            "ES CENDOL",
            "Rujak cingur merupakan salah satu makanan tradisional dari Jawa Timur, terutama di daerah asalnya Surabaya. Menurut pegiat sejarah Kota Surabaya, keberadaan rujak cingur di Kota Surabaya berawal dari tahun 1930-an yang dibawa oleh pendatang dari Pulau Madura untuk bertahan hidup dengan berdagang kuliner yakni rujak cingur",
            "Surabaya",
            R.drawable.cendol
        ),
        HotelData(
            "ES CAMPUR",
            "Rawon sebagai salah satu makanan khas asal Jawa Timur ternyata telah berusia lebih dari 1000 tahun. Hal ini terungkap dari Prasasti Taji yang dikeluarkan pada tahun 901 Masehi oleh Rakryan I Watu Tihang Pu Sanggramadurandara yang ditemukan di Ponorogo, tertulis dengan nama Rarawwan",
            "Jawa Timur",
            R.drawable.campur
        ),
    )

    val Grid = arrayListOf(
        HotelData(
            "ES OYEN",
            "Soto (juga dikenal dengan beberapa nama lokal seperti, sroto, sauto, tauto, atau coto) adalah makanan khas Indonesia seperti sop yang terbuat dari kaldu daging dan sayuran. Daging yang paling sering digunakan adalah daging sapi dan daging ayam, tetapi ada pula yang menggunakan daging babi, daging kuda atau daging kambing",
            "Jawa Timur",
            R.drawable.oyen
        ),
        HotelData(
            "ES SELENDANG MAYANG",
            "Bakso sangat populer dan dapat ditemukan di seluruh Indonesia, dari gerobak pedagang kaki lima hingga restoran besar. Berbagai jenis bakso sekarang banyak ditawarkan dalam bentuk makanan beku yang dijual di pasar swalayan ataupun mal-mal. Irisan bakso dapat juga dijadikan pelengkap jenis makanan lain seperti mi goreng, nasi goreng, sop atau capca",
            "Malang",
            R.drawable.selendang
        ),
        HotelData(
            "ES GOBAK SODOR",
            "Gudeg sangat populer di Jawa, hidangan ini merupakan hidangan populer baik sebagai masakan rumahan maupun hidangan jalanan. Gudeg juga diproduksi secara industri sebagai makanan kaleng. Gudeg juga bisa ditemui di luar Indonesia, khususnya di negara tetangga seperti Malaysia dan Singapura",
            "Jogja",
            R.drawable.gobak
        ),
        HotelData(
            "ES DOGER",
            "Asal usul rendang ditelusuri berasal dari tanah Minangkabau, Sumatera Barat. Bagi masyarakat Minang, rendang sudah ada sejak dahulu dan telah menjadi masakan tradisi yang dihidangkan dalam berbagai acara adat dan hidangan keseharian",
            "Sumatera",
            R.drawable.doger
        ),
        HotelData(
            "ES CENDOL",
            "Rujak cingur merupakan salah satu makanan tradisional dari Jawa Timur, terutama di daerah asalnya Surabaya. Menurut pegiat sejarah Kota Surabaya, keberadaan rujak cingur di Kota Surabaya berawal dari tahun 1930-an yang dibawa oleh pendatang dari Pulau Madura untuk bertahan hidup dengan berdagang kuliner yakni rujak cingur",
            "Surabaya",
            R.drawable.cendol
        ),
        HotelData(
            "ES CAMPUR",
            "Rawon sebagai salah satu makanan khas asal Jawa Timur ternyata telah berusia lebih dari 1000 tahun. Hal ini terungkap dari Prasasti Taji yang dikeluarkan pada tahun 901 Masehi oleh Rakryan I Watu Tihang Pu Sanggramadurandara yang ditemukan di Ponorogo, tertulis dengan nama Rarawwan",
            "Jawa Timur",
            R.drawable.campur
        ),


        )

}