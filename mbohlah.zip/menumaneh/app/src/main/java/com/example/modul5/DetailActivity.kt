package com.example.modul5
import android.content.DialogInterface
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.modul5.R
import com.google.android.material.textview.MaterialTextView

class DetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        // Mengambil data nama, deskripsi, dan gambar dari intent
        val getDataName = intent.getStringExtra("hotelname")
        val getDataDescription = intent.getStringExtra("description")
        val getDataImage = intent.getIntExtra("image", 0)

        // Menghubungkan variabel dengan komponen di layout
        val foodName = findViewById<MaterialTextView>(R.id.food_name)
        val foodDescription = findViewById<MaterialTextView>(R.id.food_description)
        val foodImage = findViewById<ImageView>(R.id.food_image)
        val btnTitik3 = findViewById<ImageView>(R.id.btn_titik3)

        // Menampilkan data makanan
        foodName.text = getDataName
        foodDescription.text = getDataDescription
        foodImage.setImageResource(getDataImage)

        // Memberikan aksi saat ImageView btn_titik3 diklik
        btnTitik3.setOnClickListener {
            showPopupMenu()
        }
    }

    private fun showPopupMenu() {
        // Membuat AlertDialog untuk menampilkan popup
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Opsi")
            .setMessage("Pilih opsi yang diinginkan")
            .setPositiveButton("Ubah") { dialog, _ ->
                // Aksi untuk opsi Ubah, misalnya navigasi ke halaman ubah
                // Misalnya: startActivity(Intent(this, EditActivity::class.java))
                dialog.dismiss()
            }
            .setNegativeButton("Hapus") { dialog, _ ->
                // Aksi untuk opsi Hapus
                // Misalnya: hapusData()
                dialog.dismiss()
            }
            .setCancelable(true)
            .show()
    }
}
