package com.example.modul5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class item_post : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.item_post)
    }
}